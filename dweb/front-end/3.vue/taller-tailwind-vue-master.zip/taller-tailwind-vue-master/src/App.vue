<script setup>
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
import Header from "./components/Header.vue";
import Main from "./components/Main.vue";
</script>

<template>
  <div class="text-purple-400">
    <Header />
    <Main />
  </div>
</template>

<style scoped>
</style>
