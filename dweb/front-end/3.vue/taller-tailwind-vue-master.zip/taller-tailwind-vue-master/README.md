# Taller vue.js y tailwindcss
app migrada de vanilla js a vue.js

Realizar un aplicación web que permita almacenar, agregar y editar proyectos.
